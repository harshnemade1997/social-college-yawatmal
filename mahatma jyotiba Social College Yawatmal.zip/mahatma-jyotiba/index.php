<!DOCTYPE html>
<html>
<head>
	<title>Mahatma Jyotiba Fule College Of Social Work</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="boot/bootstrap/css/bootstrap.min.css">	
	<script type="text/javascript" src="boot/bootstrap/js/bootstrap.min.js"></script>
	<script src="js/jquery-3.2.1.js"></script>
  	<script src="js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Russo+One&display=swap" rel="stylesheet">

  	<style>
        .white{
    		color: white;
    	}
    	a:hover{
   			background-color: white;
    		color: #9f7b36;
    		border-radius: 20px;
    	}
    	marquee {
        width: 100%;
        height: 100%;
        padding: 10px 0;
      }
      .box {
      	width: 100%;
		border: 2px solid #836f40;
		border-radius: 10px;
		padding-left: 10px;
		padding-right: 10px;
		}
		b{
			font-style: normal;
		}
    </style>
</head>
<body>
	<section class="">
	<div style="/*background-color: #EFDCB8">
		<div class="container">
			<div class="row">
				<div class="col-md-2 text-center">
					<img src="images/logo.png" width="150" height="150">
				</div>
				<div class="col-md-8 text-center">
					<h1 style="font-family: 'Russo One', sans-serif;">Mahatma Jyotiba Fule College Of Social Work,Yavatmal</h1>
					<h3 style="font-family: 'Russo One', sans-serif; color:green">Nurturing Youth For Social Change</h3>
					<h4>Established In 1993</h4>
				</div>	
				<div class="col-md-2 text-center">
					<img src="images/logo1.png" width="150" height="150">
				</div>
			</div>		
		</div>
	</div>
		<nav class="navbar navbar-expand-md" style="background-color:#9f7b36; padding-left: 4%">

		  	<a class="nav-link white" href="#"><b>HOME</b></a>
		  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span><i class="fa fa-caret-down" style="color: white"></i></span>
		  	</button>
		  	<div class="collapse navbar-collapse" id="collapsibleNavbar">
		    	<ul class="navbar-nav">
		      		<li class="nav-item dropdown">
				      <a class="nav-link dropdown-toggle white"  href="#" id="navbardrop" data-toggle="dropdown">
				        <b>ABOUT US</b></a>
				      <div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">Vision Mission & Objective</a>
				        <a class="dropdown-item white" href="#">Registration</a>
				        <a class="dropdown-item white" href="#">Organisation</a>
				      </div>
				    </li>
		      		<li class="nav-item dropdown">
				      <a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown">
				        <b>ACDAMIC</b></a>
				      <div class="dropdown-menu" style="background-color: #9f7b36;  border-radius: 10px;">
				        <a class="dropdown-item white" href="#">BSW MSW Certificate Course in Basic Counselling Skills</a>
				        <a class="dropdown-item white " href="#">Syllabus</a>
				        <a class="dropdown-item  white" href="#">Activity Calender</a>
				      </div>
				    </li>
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NACC</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">IQAC</a>
				        <a class="dropdown-item white " href="#">AQAR</a>
				        <a class="dropdown-item  white" href="#">SSR</a>
				    </div>
		      		</li>
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NEWS-EVENTS</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">Notice</a>
				        <a class="dropdown-item white " href="#">Activity</a>
				        <a class="dropdown-item  white" href="#">Workshop</a>
				        <a class="dropdown-item  white" href="#">Vacancy</a> 
				     </div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>GALLERY</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36;  border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Academic Events</a>
	    				<a class="dropdown-item  white" href="#">Social Events</a> 
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>LIABRABRY</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Infrastructure</a>
	    				<a class="dropdown-item  white" href="#">No. of Books</a>
	    				<a class="dropdown-item  white" href="#">No. of Journals</a> 
	    				<a class="dropdown-item  white" href="#">No. of Reference Book</a> 
	    				<a class="dropdown-item  white" href="#">E-Books</a>  
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NETWORK</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">GO's</a>
	    				<a class="dropdown-item  white" href="#">NGO's</a>
	    				<a class="dropdown-item  white" href="#">Institution</a>  
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>STUDENT CORNER</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Student Support</a>
	    				<a class="dropdown-item  white" href="#">Prevention Of Sexual Harassment</a>
	    				<a class="dropdown-item  white" href="#">Anti-Ragging Rules</a>
	    				<a class="dropdown-item  white" href="#">Alumni</a>
	    				<a class="dropdown-item  white" href="#">Placement Cell</a>
					</div>
		      		</li>        
		      		<li class="nav-item">
	        		<a class="nav-link white" href="#"><b>CONTACT US</b></a>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>USEFULL LINKS</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">www.sgbau.ac.in</a>
	    				<a class="dropdown-item  white" href="#">Social Walfare<br> Department</a>
	    			</div>
	    			</li>
		    	</ul>
		  	</div>  
		</nav>
	</section>
	<div class="container">
		<?php include('slider.php'); ?>
		<div class="row" style="padding-top:10px;">
			<div class="col-md-3">
				<div class="card" style=" width:100%; border: 2px solid #9f7b36">
					  <img class="card-img-top" src="images/president.png" alt="Card image">
					  <div class="card-body">
					    <h4 class="card-title">Hon. Dinesh Baliram Sawai</h4>
					    <p class="card-text">President, Subhedar Ramji Ambedkar Education Society, Wardha</p>
					  </div>
				</div>
			</div>
			<div class="col-md-9">
			<div class="box">
			<h3 class="text-center">Introduction</h3><hr>
			<p><b>Mahatma Jyotiba Fule College of Social Work</b> a prestigious Social Work College, affiliated to Sant Gadge Baba Amravati University Amravati, is one of the first colleges of Social Work in the district of Yavatmal. Inspired by the ideals of Mahatma Phule and Babasaheb Ambedkar, the college was established as Buddhist educational institution in August 1993 by the Subhedar Ramji Ambedkar Educational Society, Wardha which in turn was founded by honorable Dinesh Baliram Sawai, a frontline leader of Dalit and Buddhist movement, a prominent Ambedkarite and an educationalist. Subhedar Ramji Ambedkar Education Society is one of the most reputed and well known educational societies in Vidarbha region which has spread over its work in Wardha, Deoli, Hinganghat towns of Wardha and Yavatmal districts. Under the visionary leadership of honorable Dinesh Baliram Sawai, the Founder President of Subhedar Ramji Ambedkar Education Society, the society realizes the importance of education and also that traditional and formal education courses will not bring about constructive social and economical changes. The availability of professional education and training courses is must.This vision was realized with the foundation of Mahatma Jyotiba Fule College of Social Wo.....<a href="introduction.php">Continue Read</a></p>
		</div>
	</div>

		</div>
		<div class="row" style="padding-top:10px;">
			<div class="col-md-3">
				<div class="card" style=" width:100%; border: 2px solid #9f7b36">
					  <img class="card-img-top" src="images/principal.jpg" alt="Card image">
					  <div class="card-body">
					    <h4 class="card-title">Hon. Sau. Vimaltai S. Chate</h4>
					    <p class="card-text">Vice-President, Mahatma Fule College Of Social Work, Yavatmal </p>
					  </div>
				</div>
			</div>
			<div class="col-md-6">
				
			</div>
			<div class="col-md-3">
				<div class="card">
					<div class="card-body">
				<marquee class="text-center" scrollamount="2" onmouseover="this.stop();" onmouseout="this.start();" direction="up">
					<p>This is notice board.</p>
				</marquee>
			</div></div>
				
			</div>
		
				<div class="card" style="width:; margin-top:10px;">
					<div class="card-body text-center">
						<div class="row" style="padding-top: 10px;">
							<div class="col-md-6">
								<h4>Vision</h4><hr>
								<p>Promote freedom, secularism, equality and social justice enshrined in the constitution of India through planned Social Work interventions by the trained & determined professional Social Workers cadre</p>
							</div>
							<div class="col-md-6">
								<h4>Mission</h4><hr>
								<p>Create support systems especially for the underprivileged population groups or areas, and society in general and ensuring social welfare, equitable development of society in the changing world.</p>
							</div>
						</div>
					</div>
				</div>
	</div>
</div>
	<?php 
	include('footer.php');
	 ?>
</body>

</html>