<!DOCTYPE html>
<html>
<head>
  <title>org structure</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <style >
    .b{
      width: 100%;
      margin-top: 6px;
    
    }
    h1{
      text-align: center;
      color: #196F3D;
    
      font-family: 'Russo One', sans-serif;
    }


</style>
</head>
<body>

  <div style="margin-top: 5%;">
    <div class="container">
      <h1 class="display-4 ">Organisational Structure</h1>
      <div class="row">
    
          <div class="col-md-2">
            <div>
               <div class="dropdown">
                  <button class="btn btn-info dropdown-toggle b" data-toggle="dropdown"> Faculty Profile</button>
                  
                  </button>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Office</a>
                    <a class="dropdown-item" href="#">Library</a>
                  </div>
                </div>
             
            </div>
            <div>
              <button class="btn btn-info b"> Library Staff</button>
            </div>
            <div>
              <button class="btn btn-info b"> Supportive Staff</button>
            </div>
             <div>
              <button class="btn btn-info b"> Library Staff</button>
            </div>
             <div>
              <button class="btn btn-info b"> Library Staff</button>
            </div>
             <div>
              <button class="btn btn-info b"> Library Staff</button>
            </div>
          </div>   
       <div class="col-md-10"> 
              
           <?php 
         include('org/faculty.php');
          ?>  
      </div>

     </div>
    </div>
  </div>
</body>
</html>