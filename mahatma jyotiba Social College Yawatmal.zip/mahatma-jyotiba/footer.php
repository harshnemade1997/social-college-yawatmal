<!DOCTYPE html>
<html>
<head>
	<title>footer</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
  <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>


  <style>
  	.footer{
      margin-top: 5%;
  width: 100%;
  background-color:#9f7b36;
  color: white;
  	}
  	.container{
     padding-top:2%;
  	}
  	.white{
  		color: white;
  	}
  	a:hover{
  		background-color: white;
  		color: #9f7b36;
 
  </style>
</head>
<body>
<div class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-4">	
				<h5><b>IMPORTANT LINKS</b></h5> 
				<a href="#" class="white" >www.sgbau.ac.in</a><br>
				<a href="#" class="white">Social Welfare Department.</a>
			</div>
			<div class="col-md-4">	
				<h5><b>NEWSLETTER</b></h5>
				<p>Make sure you dont miss interesting happenings by joining our newsletter program.</p>
				<div class="input-group mb-3">
			    <input type="text" class="form-control" placeholder="Email">
			    <div class="input-group-append">
		        <button class="btn btn-success" type="submit">Subscribe</button>  
               </div>
           </div>
			</div>
			<div class="col-md-4">
			<div style="padding-left: 5%;">	
				 <h5><b>CONTACT US</b></h5>	
				<p>For all admission related enquiry, you may contact us on the below phone number or email.</p><br>
				<p>  <i class="fa fa-map-marker"></i>
		        Mahatma Jyotiba Pule College Of Social Work,Yavatmal.</p>
		        <i class="fa fa-phone-square"></i>	
				Call: <b>00002-222111</b><br>
				<i class="fa fa-envelope-square"></i>
                Email: <b>Mahatmaphule@gmail.com</b>
			</div>
		    </div>

		   <div style="opacity:0.9; "><p>&copy; Copyright 2019 Mahatma Pule College Of Social Work.</p></div>
  	    </div>
  	</div>
  	</div>
</div>
</body>
</html>