<!DOCTYPE html>
<html>
<head>
	<title>office</title>
	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="table-responsive">
		<table class="table table-bordered">
			<thead  style="background-color: #F0B27A;">
				<th>Name</th>
				<th>Designation</th>
				<th>image</th>
			</thead>
			<tbody  style="background-color: #D0D3D4;">
				<tr>
				<td> Mr. Pawan J. Thakre </td>
				<td>Office Superintedent</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Sandeep G. Jadhao </td>
				<td>Accountant</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Swatej R. Deshmukh </td>
				<td>File Clerk</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Abhishek R. Jirapure </td>
				<td>Typist </td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Dhananjay D. Rahate</td> 
				<td>Peon/Shipai</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Kshirsagar D. Naik</td>
				 <td>Watchman</td>
				 <td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Milind R. Dohane</td> 
				<td>Watchman</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Ramkrushna B. Tawade </td>
				<td>Watchman</td>
				<td><img src=""> </td>
				</tr>
				<tr>
				<td> Mr. Anupkumar P. Gajghate </td>
				<td>Sweeper</td>
				<td><img src=""> </td>
				</tr>
			</tbody>
		</table>
	    </div>
	</div>
</body>
</html>