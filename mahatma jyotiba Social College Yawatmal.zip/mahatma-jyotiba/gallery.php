<!DOCTYPE html>
<html>
<head>
	<title>Gallery</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script src="js/jquery-3.2.1.js"></script>
  	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		<h1 class="display-3">Gallery</h1>
	<div class="row">
		<div class="col-md-4">
			<img src="images/banner-1.jpg" style="width: 100%; border: 2px solid black;">
		</div>
		<div class="col-md-4">
			<img src="images/banner-2.jpeg" style="width: 100%; border: 2px solid black;">
		</div>
		<div class="col-md-4">
			<img src="images/banner-3.jpeg" style="width: 100%; border: 2px solid black;">
		</div>
	</div>
	<div class="row" style="padding-top: 5px;">
		<div class="col-md-6">
			<img src="images/banner-4.jpg" style="width: 100%; border: 2px solid black;">
		</div>
		<div class="col-md-6">
			<img src="images/banner-5.jpg" style="width: 100%; border: 2px solid black;">
		</div>
	</div>
	<div class="col-md-12" style="padding-top: 5px;">
		<img src="images/clg.jpg" style="width: 100%; border: 2px solid black;">
	</div>
</div>
</body>
</html>