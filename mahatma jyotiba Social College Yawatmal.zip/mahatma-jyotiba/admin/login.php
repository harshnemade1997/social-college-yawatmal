<!DOCTYPE html>
<html>
<head>
	<title>Admin Log In</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
</head>
<body style="background-image: url(../images/college.jpg); background-repeat: no-repeat; width: 100%; height: 100%;">
	<div >
	<div class="container" style="padding-top: 10%; width: 50%">
		<div class="card" style="background-color: #f8f9fa;">
			<form method="POST" style="padding-bottom: 2%">
				<h1 class="display-4" style="margin-left: 10px;"><b>Admin Log In</b></h1>
				<hr>
				<div style="padding-left: 5%;">
	  				<div class="form-group">
	    				<label for="email">Email address</label>
	    				<input type="email" class="form-control" name="email" placeholder="Enter email">
	  				</div>
				    <div class="form-group">
				    	<label for="password">Password</label>
				    	<input type="password" class="form-control" name="password" placeholder="Enter Password">
				  	</div>
				</div>
				<div class="row" style="margin-left: 5px; margin-right: 5px;">
				<div class="col-md-5 text-center">
	  				<button type="submit" class="btn btn-success btn-block" name="login">Log In</button>
				</div>
				<div class="col-md-2 text-center">
					<p>OR</p>
				</div>
					<div class="col-md-5 text-center">
	  				<button type="submit" class="btn btn-primary btn-block" name="login">Sign Up</button>
				</div>
			</div>
			</form>
		</div>
	</div>
</div>
</body>
</html>