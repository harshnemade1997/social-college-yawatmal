<!DOCTYPE html>
<html>
<head>
	<title>library staff</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="container">
		<div class="table-responsive">
			<table class="table table-bordered">
				<thead style="background-color: #F0B27A;">
					<th>Name</th>
					<th>Designation</th>
					<th>Image</th>
				</thead>
				<tbody style="background-color: #D0D3D4;">
					<tr>
	<td>Mr. Pawan N. Wankhede</td> 
	<td> Asstt.Librarian </td>
	<td><img src=""></td>
	</tr>
	<tr> 
	<td>Mis.Vishakha P. Dangare</td> 
	<td> Asstt.Librarian</td>
	<td><img src=""></td>
</tr>
<tr>
	<td>Mr. Rajesh N. Khaire</td> 
	<td> Library Clerk</td>
	<td><img src=""></td>
</tr>
<tr>
	<td>Mr. Tejas V. Deshamukh</td> 
	<td> Library- Assistant</td>
	<td><img src=""></td>
</tr>
<tr>
	<td>Mr.Vijay S. Hingaspure</td> 
	<td> Library- Assistant</td>
	<td><img src=""></td>
	</tr>
	<tr>
	<td>Ku. Prti R. Nagdeote</td> 
	<td> Library- Pron</td>
	<td><img src=""></td>
		</tr>			
				</tbody>
			</table>
		</div>
	</div>




</body>
</html>