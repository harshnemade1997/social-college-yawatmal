<!DOCTYPE html>
<html lang="en">
<head>
  <title>teaching staff</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <script src="js/jquery-3.2.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
   <div class="table-responsive">
    <table class="table table-bordered">
      <thead style="background-color: #F0B27A;">  
        <th>Name</th>
        <th>Designation and qualification</th>
        <th>Mobile Number</th>
        <th>image</th>
      </thead>
      <tbody style="background-color: #D0D3D4;">
              <tr>
             <td>Swati Ugemuge</td>
             <td>  Assit. Prof.<br>M. S.W. M. Phil. (CD) SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Deepak R. Ate</td>
            <td>Assit. Prof.<br> M. S.W. (LWPM) M.A.NET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Devidas P. Shambharkar</td>
            <td> Assit. Prof.<br> M. S.W(CD) SET,NET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
             <td>Anil V. Deshamukh</td>
             <td>Assit. Prof.<br> M. S. W. M. Phil.(CD)</td>
             <td>Mobile Number</td>
             <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Rahul G. Gondane</td>
            <td> Assit. Prof.<br> M. S. W. M. Phil. (CD)</td>
            <td>Mobile Number</td>
             <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td>Homraj T. Rathod</td>
            <td> Assit. Prof. <br> M. A. M. Phil. (Sco)</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr><td> Omprakash J Chandak </td>
            <td> Assit. Prof.<br>M. S. W. (CD)</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td>Mohanish B. Sawai</td>
            <td> Assit. Prof. <br> M. S.W. (LWPM)M.Phil.NET,SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Dr.Ganesh R.Gadekar</td>
            <td>Assit. Prof.<br> Ph.D.M.S.W.(CD)M.A.B.Ed</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Dr.Pranju R. Hirekhan</td>
            <td> Assit. Prof.<br> Ph.D. M.S.W. (CD & FCW) MPhil</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"</td>
            </tr>
            <tr>
            <td>Takshashila H. Motghare</td>
            <td>Assit. Prof. <br> M.A.MEd.M.S.W.M.Phil,SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Ratndip B. Gangale </td>
            <td>Assit. Prof.<br>M.S.W.(CD)NET,SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Vikas N. Adyalkar</td>
            <td>Assit. Prof.<br>M.S.W.(HRM/HRD),NET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td>Narendra N. Daware</td>
            <td>Assit. Prof. <br> Ph.D,M.A.(Psy) SET,NET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Dr. Siddharth Gangale</td>
            <td> >Assit. Prof.<br>Ph.D, M.S.W. SET, NET (CD) DJ &MC.</td>.
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Rahul J. Jondhale</td>.
            <td>Assit Prof.<br> M.S.W.SET (LWPM)</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Vasanta s. Wanjari</td>
            <td>Assit Prof.<br> M.S.W. M.Phil (CD) SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Suhas U Waghamare</td>
            <td>Assit Prof.<br> M.S.W. M.Phil (CD) SET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
            <tr>
            <td> Arun V. Shete</td>
            <td>Assit Prof.<br> M.S.W. (CD) SET,NET</td>
            <td>Mobile Number</td>
            <td><img src="images/avtar.png" height="80" width="80"></td>
            </tr>
      </tbody>
  </table>
</div>
</div>
</body>
</html>
