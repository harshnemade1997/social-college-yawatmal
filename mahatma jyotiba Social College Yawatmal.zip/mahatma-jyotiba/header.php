<!DOCTYPE html>
<html>
<head>
	<title>Header</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script src="js/jquery-3.2.1.js"></script>
  	<script src="js/bootstrap.min.js"></script>
    <style>
        .white{
    		color: white;
    	}
    	a:hover{
   			background-color: white;
    		color: #9f7b36;
    		border-radius: 20px;
    	}
    </style>

</head>
<body>
	<section class="">
		<div>
			
		</div>
		<div class="container">
		<nav class="navbar navbar-expand-md" style="background-color:#9f7b36; padding-left: 4%">

		  	<a class="nav-link white" href="#"><b>HOME</b></a>
		  	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span><i class="fa fa-caret-down" style="color: white"></i></span>
		  	</button>
		  	<div class="collapse navbar-collapse" id="collapsibleNavbar">
		    	<ul class="navbar-nav">
		      		<li class="nav-item dropdown">
				      <a class="nav-link dropdown-toggle white"  href="#" id="navbardrop" data-toggle="dropdown">
				        <b>ABOUT US</b></a>
				      <div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">Vision Mission & Objective</a>
				        <a class="dropdown-item white" href="#">Registration</a>
				        <a class="dropdown-item white" href="#">Organisation</a>
				      </div>
				    </li>
		      		<li class="nav-item dropdown">
				      <a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown">
				        <b>ACDAMIC</b></a>
				      <div class="dropdown-menu" style="background-color: #9f7b36;  border-radius: 10px;">
				        <a class="dropdown-item white" href="#">BSW MSW Certificate Course in Basic Counselling Skills</a>
				        <a class="dropdown-item white " href="#">Syllabus</a>
				        <a class="dropdown-item  white" href="#">Activity Calender</a>
				      </div>
				    </li>
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NACC</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">IQAC</a>
				        <a class="dropdown-item white " href="#">AQAR</a>
				        <a class="dropdown-item  white" href="#">SSR</a>
				    </div>
		      		</li>
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NEWS-EVENTS</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
				        <a class="dropdown-item white" href="#">Notice</a>
				        <a class="dropdown-item white " href="#">Activity</a>
				        <a class="dropdown-item  white" href="#">Workshop</a>
				        <a class="dropdown-item  white" href="#">Vacancy</a> 
				     </div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>GALLERY</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36;  border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Academic Events</a>
	    				<a class="dropdown-item  white" href="#">Social Events</a> 
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>LIABRABRY</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Infrastructure</a>
	    				<a class="dropdown-item  white" href="#">No. of Books</a>
	    				<a class="dropdown-item  white" href="#">No. of Journals</a> 
	    				<a class="dropdown-item  white" href="#">No. of Reference Book</a> 
	    				<a class="dropdown-item  white" href="#">E-Books</a>  
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>NETWORK</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">GO's</a>
	    				<a class="dropdown-item  white" href="#">NGO's</a>
	    				<a class="dropdown-item  white" href="#">Institution</a>  
					</div>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>STUDENT CORNER</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">Student Support</a>
	    				<a class="dropdown-item  white" href="#">Prevention Of Sexual Harassment</a>
	    				<a class="dropdown-item  white" href="#">Anti-Ragging Rules</a>
	    				<a class="dropdown-item  white" href="#">Alumni</a>
	    				<a class="dropdown-item  white" href="#">Placement Cell</a>
					</div>
		      		</li>        
		      		<li class="nav-item">
	        		<a class="nav-link white" href="#"><b>CONTACT US</b></a>
		      		</li>    
		      		<li class="nav-item dropdown">
	        		<a class="nav-link dropdown-toggle white" href="#" id="navbardrop" data-toggle="dropdown"><b>USEFULL LINKS</b></a>
	        		<div class="dropdown-menu" style="background-color: #9f7b36; border-radius: 10px;">
	        			<a class="dropdown-item  white" href="#">www.sgbau.ac.in</a>
	    				<a class="dropdown-item  white" href="#">Social Walfare<br> Department</a>
	    			</div>
	    			</li>
	    			        
		    	</ul>
		  	</div>  
		</nav>
	</div>
	</section>
</body>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</html>

